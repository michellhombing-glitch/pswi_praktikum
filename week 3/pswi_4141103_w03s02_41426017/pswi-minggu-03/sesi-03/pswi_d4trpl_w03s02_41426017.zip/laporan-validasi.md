1. validator index html
tidak eror sama sekali 

2. validator kegiatan html
warning, karena pada line 28, colomn 5, to line 28, colomn 34
kalau diubah border menjadi 0, tabel akan hilang

3. validator kontak html
tidak eror sama sekali 

Catatan sumber dan lisensi gambar : gambar yang saya ambil dari aplikasi photo tidak di web 